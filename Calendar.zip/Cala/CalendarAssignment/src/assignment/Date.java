package assignment;

import java.util.Scanner;

public class Date implements Comparable<Date> {
	Scanner input = new Scanner(System.in);

    public Date(int year, int month, int day) throws IllegalArgumentException{
	// year between 2014-2020
    	// month between 1-12
    	// day between 1-31
    	System.out.println("Chose a date");
    	year= input.nextInt();
    	month= input.nextInt();
    	day= input.nextInt();
    	
    	if(year <= 2020 && year >= 2014 ) {
    		System.out.println(year);
    		
    	}
    	if(month <=12 && month >= 1) {
    		System.out.println(month);
    	}
    	if (day <= 31 && day >= 1) {
    		System.out.println(day);
    	}
    	throw new IllegalArgumentException("value is invalid");
    }
    public int getyear() {
		return getyear();
		// TODO Auto-generated method stub
		
	}
	public int getday() {
		return getday();
		// TODO Auto-generated method stub
		
	}
	public int getmonth() {
		return getmonth();
		// TODO Auto-generated method stub
		
	}
	@Override
	public String toString() {
		return getmonth()  + "/" + getday() + "/" + getyear() ;
	}
    
    public boolean equals(Object obj){
        Date otherDate = (Date)obj;
        if (otherDate.equals(toString())) {
        	
        }
		return true;
    }

 public int compareTo (Date otherDate) {
	 if (Date.equals(otherDate)){
		return 0; 
	 }
	 else (Date < otherDate){
		 return 1;
		 
	 } else (Date > otherDate)){
		 return -1;
	 }
}

}
