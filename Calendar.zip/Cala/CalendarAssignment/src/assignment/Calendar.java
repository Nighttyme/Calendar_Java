package assignment;

import java.util.ArrayList;
import java.util.Scanner;

public class Calendar {
	Scanner input = new Scanner(System.in);

	static final int MAXEVENTS=4;
	 ArrayList<Integer> e = new ArrayList<Integer>(MAXEVENTS);
	int numEvents;
	
	boolean addEvent(Event e) {
		System.out.println("Enter an event");
		int event= input.nextInt();
		
		if (numEvents == MAXEVENTS) {
			 for (int i = 0; i < numEvents; i++) {
				 e.add(event);
			 }
			 return true;
		}
		return false;
		
	}
	int findEvent(Event e) {
		System.out.println("Enter day to look for an event");
		int find = input.nextInt();
		 for (int i = 0; i < 4; i++) {
			 
		 }
		return find;
	}
	boolean removeEvent(Event e) {
		System.out.println("Enter event to remove for an event");
		int remove1 = input.nextInt();
		 for (int i = 0; i < numEvents; i++) {
			e.remove(remove1);
		 }
	
	return true;
}
	return false;
	}

}
