package assignment;

import java.util.Scanner;


public class Event{
	Scanner input = new Scanner(System.in);

public Event (Date date, int start, int end, String description) throws IllegalArgumentException{
 
	System.out.println("Start time/hour of the event");
	start= input.nextInt();
	System.out.println("End time/hour of the event");
	end= input.nextInt();
	System.out.println("Description of the event");
	description= input.nextLine();
	
	if (start <= end) {
		
	
}
	throw new IllegalArgumentException("invalid entry");
}

 void add(int event) {
	// TODO Auto-generated method stub
	
}

public void remove(int remove1) {
	// TODO Auto-generated method stub
	
}
}
